import bcrypt from "bcryptjs";
import * as coachRepo from "../coaches.repository";
import {
  checkCoachAvailable,
  createCoachByAdmin,
  createMySchedule,
  getAvailableCoachSchedules,
  getMyIncome,
  updateCoachStatus,
  updateMyFee,
} from "../coaches.service";

jest.mock("bcryptjs", () => ({
  __esModule: true,
  default: {
    hash: jest.fn(),
  },
}));

jest.mock("../coaches.repository", () => ({
  findAllApprovedCoaches: jest.fn(),
  findCoachById: jest.fn(),
  findAvailableCoachSchedules: jest.fn(),
  findCoachByUserId: jest.fn(),
  updateCoachProfile: jest.fn(),
  updateCoachExpertise: jest.fn(),
  updateCoachFee: jest.fn(),
  findCoachSchedules: jest.fn(),
  checkScheduleOverlap: jest.fn(),
  createCoachSchedule: jest.fn(),
  findScheduleById: jest.fn(),
  updateCoachSchedule: jest.fn(),
  deleteCoachSchedule: jest.fn(),
  findAllCoachesAdmin: jest.fn(),
  createCoachAdminTransaction: jest.fn(),
  findPendingCoaches: jest.fn(),
  updateCoachStatus: jest.fn(),
  findCoachByIdAdmin: jest.fn(),
  updateUserAvatar: jest.fn(),
  findCoachIncome: jest.fn(),
}));

jest.mock("../../../utils/upload", () => ({
  validateAndSaveFile: jest.fn(),
  deleteFile: jest.fn(),
}));

jest.mock("@/utils/AppError", () => ({
  AppError: class AppError extends Error {
    statusCode: number;
    constructor(message: string, statusCode: number) {
      super(message);
      this.statusCode = statusCode;
    }
  },
}));

const mockedRepo = jest.mocked(coachRepo);
const mockedBcrypt = jest.mocked(bcrypt);

describe("coaches.service", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe("getAvailableCoachSchedules", () => {
    it("requires bookingDate, startTime and endTime", async () => {
      await expect(getAvailableCoachSchedules("", "08:00", "09:00")).rejects.toThrow();
      await expect(getAvailableCoachSchedules("2999-01-01", "", "09:00")).rejects.toThrow();
      expect(mockedRepo.findAvailableCoachSchedules).not.toHaveBeenCalled();
    });

    it("returns only schedules that are not expired", async () => {
      mockedRepo.findAvailableCoachSchedules.mockResolvedValue([
        {
          CoachScheduleID: 1,
          WorkingDate: "2999-01-01",
          StartTime: "08:00",
          EndTime: "09:00",
          Status: "Available",
        },
      ] as any);

      const result = await getAvailableCoachSchedules("2999-01-01", "08:00", "09:00");

      expect(result).toHaveLength(1);
      expect(mockedRepo.findAvailableCoachSchedules).toHaveBeenCalledWith(
        "2999-01-01",
        "08:00",
        "09:00"
      );
    });
  });

  describe("createMySchedule", () => {
    it("creates schedule for approved coach when there is no overlap", async () => {
      mockedRepo.findCoachByUserId.mockResolvedValue({
        CoachID: 5,
        Status: "Approved",
      } as any);
      mockedRepo.checkScheduleOverlap.mockResolvedValue(false);
      mockedRepo.createCoachSchedule.mockResolvedValue({
        CoachScheduleID: 10,
        CoachID: 5,
      } as any);

      const result = await createMySchedule(7, {
        workingDate: "2999-01-01",
        startTime: "08:00",
        endTime: "10:00",
      });

      expect(result.CoachScheduleID).toBe(10);
      expect(mockedRepo.createCoachSchedule).toHaveBeenCalledWith({
        coachId: 5,
        workingDate: "2999-01-01",
        startTime: "08:00",
        endTime: "10:00",
      });
    });

    it("rejects schedule creation when coach is not approved", async () => {
      mockedRepo.findCoachByUserId.mockResolvedValue({
        CoachID: 5,
        Status: "Pending",
      } as any);

      await expect(
        createMySchedule(7, {
          workingDate: "2999-01-01",
          startTime: "08:00",
          endTime: "10:00",
        })
      ).rejects.toThrow();
      expect(mockedRepo.createCoachSchedule).not.toHaveBeenCalled();
    });

    it("rejects schedule creation when time overlaps", async () => {
      mockedRepo.findCoachByUserId.mockResolvedValue({
        CoachID: 5,
        Status: "Approved",
      } as any);
      mockedRepo.checkScheduleOverlap.mockResolvedValue(true);

      await expect(
        createMySchedule(7, {
          workingDate: "2999-01-01",
          startTime: "08:00",
          endTime: "10:00",
        })
      ).rejects.toThrow();
      expect(mockedRepo.createCoachSchedule).not.toHaveBeenCalled();
    });
  });

  describe("updateMyFee", () => {
    it("updates fee when hourly rate is valid", async () => {
      mockedRepo.findCoachByUserId.mockResolvedValue({
        CoachID: 5,
      } as any);
      mockedRepo.updateCoachFee.mockResolvedValue({
        CoachID: 5,
        HourlyRate: 200000,
      } as any);

      const result = await updateMyFee(7, { hourlyRate: 200000 });

      expect(result.HourlyRate).toBe(200000);
      expect(mockedRepo.updateCoachFee).toHaveBeenCalledWith(5, { hourlyRate: 200000 });
    });

    it("rejects invalid hourly rate", async () => {
      mockedRepo.findCoachByUserId.mockResolvedValue({
        CoachID: 5,
      } as any);

      await expect(updateMyFee(7, { hourlyRate: 1000 })).rejects.toThrow();
      expect(mockedRepo.updateCoachFee).not.toHaveBeenCalled();
    });
  });

  describe("updateCoachStatus", () => {
    it("updates coach status when coach exists", async () => {
      mockedRepo.findCoachByIdAdmin.mockResolvedValue({
        CoachID: 5,
        Status: "Pending",
      } as any);
      mockedRepo.updateCoachStatus.mockResolvedValue({
        CoachID: 5,
        Status: "Approved",
      } as any);

      const result = await updateCoachStatus(5, "Approved");

      expect(result.Status).toBe("Approved");
      expect(mockedRepo.updateCoachStatus).toHaveBeenCalledWith(5, "Approved");
    });

    it("rejects invalid coach status", async () => {
      await expect(updateCoachStatus(5, "Unknown" as any)).rejects.toThrow();
      expect(mockedRepo.findCoachByIdAdmin).not.toHaveBeenCalled();
    });
  });

  describe("checkCoachAvailable", () => {
    it("returns true when an available schedule covers requested time", async () => {
      mockedRepo.findCoachSchedules.mockResolvedValue([
        {
          WorkingDate: "2999-01-01",
          StartTime: "08:00",
          EndTime: "12:00",
          Status: "Available",
        },
      ] as any);

      await expect(
        checkCoachAvailable(5, "2999-01-01", "09:00", "10:00")
      ).resolves.toBe(true);
    });

    it("returns false when no available schedule covers requested time", async () => {
      mockedRepo.findCoachSchedules.mockResolvedValue([
        {
          WorkingDate: "2999-01-01",
          StartTime: "08:00",
          EndTime: "09:00",
          Status: "Available",
        },
      ] as any);

      await expect(
        checkCoachAvailable(5, "2999-01-01", "09:00", "10:00")
      ).resolves.toBe(false);
    });
  });

  describe("createCoachByAdmin", () => {
    it("hashes password and creates coach account in transaction", async () => {
      mockedBcrypt.hash.mockResolvedValue("hashed-password" as never);
      mockedRepo.createCoachAdminTransaction.mockResolvedValue(99 as any);

      const result = await createCoachByAdmin({
        fullName: "Coach A",
        email: "coach@example.com",
        password: "123456",
        phoneNumber: "0912345678",
        hourlyRate: 200000,
        specialization: "Beginner",
      } as any);

      expect(result).toBe(99);
      expect(mockedBcrypt.hash).toHaveBeenCalledWith("123456", 12);
      expect(mockedRepo.createCoachAdminTransaction).toHaveBeenCalledWith(
        expect.objectContaining({
          email: "coach@example.com",
          passwordHash: "hashed-password",
        })
      );
    });
  });

  describe("getMyIncome", () => {
    it("calculates total and monthly income from completed sessions", async () => {
      mockedRepo.findCoachByUserId.mockResolvedValue({
        CoachID: 5,
      } as any);
      mockedRepo.findCoachIncome.mockResolvedValue([
        {
          BookingID: 1,
          BookingType: "Coach",
          PlayerName: "Player A",
          WorkingDate: "2999-01-10",
          StartTime: "08:00",
          EndTime: "10:00",
          WorkingHours: 2,
          CoachFee: 400000,
          HourlyRate: 200000,
          Status: "Completed",
        },
        {
          BookingID: 2,
          BookingType: "Coach",
          PlayerName: "Player B",
          WorkingDate: "2999-01-15",
          StartTime: "10:00",
          EndTime: "11:00",
          WorkingHours: 1,
          CoachFee: 0,
          HourlyRate: 200000,
          Status: "Completed",
        },
      ] as any);

      const result = await getMyIncome(7);

      expect(result.summary.totalSessions).toBe(2);
      expect(result.summary.totalWorkingHours).toBe(3);
      expect(result.summary.totalIncome).toBe(600000);
      expect(result.monthlyIncome[0]).toEqual(
        expect.objectContaining({
          month: "2999-01",
          sessions: 2,
          workingHours: 3,
          income: 600000,
        })
      );
    });
  });
});
