# Huong dan lam bao cao Unit Test cho PCS

## 1. Pham vi Unit Test

Du an PCS hien tai nen tap trung Unit Test vao cac module backend co nhieu logic nghiep vu:

| Module | Ly do chon |
|---|---|
| Auth | Kiem tra dang ky, OTP, dang nhap, khoa tai khoan |
| Bookings | Chuc nang loi cua he thong: dat san, dat HLV, dat san nhom, huy booking |
| Courts / CourtSlots | Kiem tra san trong, tao slot, trung slot, sinh slot hang loat |
| Coaches | Kiem tra lich day, hoc phi, duyet coach, thu nhap |
| Player Matching | Kiem tra thuat toan tinh diem ghep cap |
| Play Invitations | Kiem tra gui, chap nhan, tu choi loi moi |

Module Tournaments khong dua vao Unit Test trong bao cao nay vi source backend hien tai chua co module/table tuong ung.

## 2. Cach cai dat test framework

Tai thu muc `backend`, cai them Jest:

```bash
npm install -D jest ts-jest @types/jest
```

Them script vao `backend/package.json`:

```json
{
  "scripts": {
    "test": "jest",
    "test:unit": "jest --runInBand",
    "test:coverage": "jest --coverage"
  }
}
```

Copy file `jest.config.js` va `jest.setup.ts` vao thu muc `backend`.

## 3. Cau truc file test can copy vao project

```txt
backend/jest.config.js
backend/jest.setup.ts
backend/src/modules/auth/__tests__/auth.service.spec.ts
backend/src/modules/bookings/__tests__/bookings.service.spec.ts
backend/src/modules/courts/__tests__/courts.service.spec.ts
backend/src/modules/coaches/__tests__/coaches.service.spec.ts
backend/src/modules/player-matching/__tests__/player-matching.service.spec.ts
backend/src/modules/play-invitations/__tests__/play-invitations.service.spec.ts
```

## 4. Lenh chay Unit Test

```bash
cd backend
npm run test:unit
```

Neu muon xem do bao phu:

```bash
npm run test:coverage
```

## 5. Bang Unit Test dua vao bao cao

| TC ID | Module | Test case | Expected result |
|---|---|---|---|
| UT-AUTH-01 | Auth | Dang ky thanh cong khi email va so dien thoai chua ton tai | Tao pending register va gui OTP |
| UT-AUTH-02 | Auth | Dang ky that bai khi email da ton tai | Nem loi, khong tao pending register |
| UT-AUTH-03 | Auth | Xac thuc OTP hop le | Tao tai khoan Player va xoa pending register |
| UT-AUTH-04 | Auth | OTP sai | Tang so lan nhap sai OTP |
| UT-AUTH-05 | Auth | Dang nhap dung email/password | Tra ve access token va thong tin user |
| UT-AUTH-06 | Auth | Dang nhap sai password | Tang failed login va nem loi |
| UT-AUTH-07 | Auth | Dang nhap tai khoan Locked | Tu choi dang nhap |
| UT-BOOK-01 | Bookings | Tao booking san khi user, san va slot hop le | Tao booking thanh cong |
| UT-BOOK-02 | Bookings | Player tao booking thanh toan tai quay | Bi tu choi vi khong phai Staff/Admin |
| UT-BOOK-03 | Bookings | Dat san khi khong co slot trong | Nem loi va khong tao booking |
| UT-BOOK-04 | Bookings | Dat HLV da duyet va co lich trong | Tao coach booking, tinh dung coach fee |
| UT-BOOK-05 | Bookings | Dat HLV chua duyet | Bi tu choi |
| UT-BOOK-06 | Bookings | Dat san nhom qua 2 gio | Bi tu choi |
| UT-BOOK-07 | Bookings | Dat san nhom co du thanh vien | Tao team booking thanh cong |
| UT-BOOK-08 | Bookings | Huy booking PendingPayment | Chuyen Cancelled, khong tao refund |
| UT-BOOK-09 | Bookings | Thanh toan booking khong thuoc user | Bi tu choi |
| UT-COURT-01 | Courts | Lay chi tiet san ton tai | Tra ve thong tin san |
| UT-COURT-02 | Courts | Tim san trong thieu start/end time | Bi tu choi input |
| UT-COURT-03 | Courts | Tao slot moi | Tao slot thanh cong |
| UT-COURT-04 | Courts | Tao slot trung nhung Available | Cap nhat gia slot |
| UT-COURT-05 | Courts | Tao slot trung da Booked/Holding | Bi tu choi |
| UT-COURT-06 | Courts | Cap nhat status slot hop le | Cap nhat thanh cong |
| UT-COURT-07 | Courts | Sinh slot hang loat | Tao slot moi va bo qua slot trung |
| UT-COACH-01 | Coaches | Lay lich HLV trong | Tra ve lich chua het han |
| UT-COACH-02 | Coaches | Coach da duyet tao lich moi | Tao lich thanh cong |
| UT-COACH-03 | Coaches | Coach chua duyet tao lich | Bi tu choi |
| UT-COACH-04 | Coaches | Tao lich bi trung | Bi tu choi |
| UT-COACH-05 | Coaches | Cap nhat hoc phi hop le | Cap nhat thanh cong |
| UT-COACH-06 | Coaches | Cap nhat hoc phi khong hop le | Bi tu choi |
| UT-COACH-07 | Coaches | Admin duyet coach | Cap nhat status thanh Approved |
| UT-COACH-08 | Coaches | Kiem tra coach co lich bao phu khung gio | Tra ve true/false dung |
| UT-COACH-09 | Coaches | Tinh thu nhap coach | Tong hop tong buoi, tong gio, tong tien |
| UT-MATCH-01 | Player Matching | Tinh diem role attacker/defender | Diem role cao nhat |
| UT-MATCH-02 | Player Matching | Tinh diem skill/experience | Diem giam theo do chenh lech |
| UT-MATCH-03 | Player Matching | Tinh diem trung lich ranh | Tra ve 0/70/100 theo overlap |
| UT-MATCH-04 | Player Matching | Luu ho so moi | Goi createProfile |
| UT-MATCH-05 | Player Matching | Cap nhat ho so da ton tai | Goi updateProfile |
| UT-MATCH-06 | Player Matching | Tim dong doi khi thieu gio ranh | Bi tu choi |
| UT-MATCH-07 | Player Matching | Sap xep ung vien theo matchingScore | Ung vien diem cao dung dau |
| UT-INV-01 | Invitations | Gui loi moi khi sender chua co profile | Bi tu choi |
| UT-INV-02 | Invitations | Gui loi moi cho chinh minh | Bi tu choi |
| UT-INV-03 | Invitations | Gui loi moi trung dang Pending | Bi tu choi |
| UT-INV-04 | Invitations | Gui InviteToPlay hop le | Tao invitation thanh cong |
| UT-INV-05 | Invitations | Chap nhan loi moi khong phai receiver | Bi tu choi |
| UT-INV-06 | Invitations | Chap nhan InviteToGroup khi nhom day | Chuyen invitation sang Expired |
| UT-INV-07 | Invitations | Chap nhan InviteToPlay | Tao nhom tu dong trong transaction |
| UT-INV-08 | Invitations | Tu choi invitation | Chuyen status sang Rejected |

## 6. Noi dung viet vao bao cao

### Gioi thieu

Unit Test duoc su dung de kiem tra cac ham nghiep vu rieng le trong backend cua he thong Pickleball Booking System. Cac test duoc viet cho service layer va validation layer, trong do database/repository, email, notification va cac service ben ngoai duoc mock de dam bao test chay doc lap.

### Cong cu su dung

Nhom su dung Jest ket hop ts-jest de viet Unit Test cho backend TypeScript. Cac repository duoc mock bang `jest.mock`, giup kiem tra logic service ma khong can ket noi SQL Server that.

### Cach thuc kiem thu

Moi Unit Test tap trung vao mot quy tac nghiep vu cu the, vi du: khong cho dat san khi slot khong kha dung, khong cho coach chua duyet tao lich, khong cho gui loi moi trung lap, hoac tinh diem matching theo vai tro, trinh do, kinh nghiem va lich ranh.

### Ket luan

Bo Unit Test giup kiem tra cac chuc nang quan trong nhat cua PCS gom dang nhap/dang ky, dat san, quan ly slot san, dat lich HLV, ghep cap nguoi choi va xu ly loi moi. Viec mock repository giup test chay nhanh, doc lap va phu hop voi muc tieu Unit Test.
